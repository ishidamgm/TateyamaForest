devtools::install_github("ishidamgm/TateyamaForest")
library(TateyamaForest)
help(package="TateyamaForest")
dd3
