## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(TateyamaForest)

## ----plot---------------------------------------------------------------------
plot(1:10)
head(dd3)
# par(mfrow=c(1,4))
# vital_mortality(dd2)        # all species ####

