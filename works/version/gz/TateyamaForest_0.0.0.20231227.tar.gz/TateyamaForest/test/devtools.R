# devtools.R

getwd()

fs::dir_tree()



# rm(list=ls())
# ls()

# devtools::install_github("ishidamgm/TateyamaForest")
library(TateyamaForest)
help(package="TateyamaForest")
data(package="TateyamaForest")
dd3
clm_f
clm_dbh
plt[,clm_yr]

## restore the saved values to the current environment
local({
  load("data/TateyamaForest_dd3_plt.RData")
  ls()
})



